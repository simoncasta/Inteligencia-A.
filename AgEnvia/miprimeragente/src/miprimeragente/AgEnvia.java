
package miprimeragente;

import jade.core.*;
import jade.core.behaviours.*;
import jjade.lang.acl.*;


public class AgEnvia extends Agent  {
    
    
    class comportEnvia extends SimpleBehaviour {
        
        String nameAgent; 
        
        public comportEnvia (String n) {nameAgent = n};
        public void action(){
            
            doWait(20000);
             ACLMessage acl = new  ACLMenssage(ACLMessage.REQUEST);
        AID agrec = nwe AID (nameAgent,AID.ISLOCALNAME);
        acl.addReceiver(agrec);
        acl.setContent("Mensajel");
        send(acl);
        }
        public boolean done(){
            return true;
        }
    }
    protected  void setup(){
        Object [] listaparametros = getArguments();
String nameAgentR = (String) listaparametros[0];

System.out.println("Hola mundo soy el primer Agente" +  getLocalName());

comportEnvia ce= new comporEnvia(nameAgenteR);
addBehavour (ce);
    }
}
