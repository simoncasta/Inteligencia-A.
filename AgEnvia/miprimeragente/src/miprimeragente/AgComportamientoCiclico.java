/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package miprimeragente;
import jade.core.*;
import jade.core.behaviours.*;

/**
 *
 * @author angelicabibiana
 */
public class AgComportamientoCiclico extends Agent   {
    
    class Comportamiento2 extends CyclicBehaviour {
    int limite=100;
    public void action()
    {
        limite++;
        System.out.println("limite es" + limite);
    
    }        
    }
     protected void setup () {
         System.out.println("hola soy un agente con un comportamiento ciclico");
         Comportamiento2 c2 = new Comportamiento2();
         addBehaviour(c2);
         System.out.println("ya se introdujo el comportamiento");
     }
}
