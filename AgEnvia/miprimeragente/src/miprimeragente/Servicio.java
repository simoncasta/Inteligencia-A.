package miprimeragente;




    public String servicio;
    


import jade.core.Agent;
import jade.domain.FIPAException;
import jade.domain.DFService;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.FIPAAgentManagement.DFAgentDescription;


public class Servicio  extends Agent{
    
    protected void setup ()
    {
        Object [] arg2 = getArguments();
        
        Servicio = (String) arg2[0];
        
        System.out.println("El nombre del agente es :"+ this.getLocalName() + " : Yo soy el servicio" + Servicio);
        registrerService();
        
    }
        
        private void registrerService()
        {
            DFAgentDescription dfd = new DfAgentDescription();
            dfd.setName(this.getAID());
            
            ServiceDescription sd = new ServiceDescription();
            sd.setType(servicio);
            sd.setName(servicio);
            
            dfd.addServices(sd);
            try{
                DFService.registrer(this,dfd);
            }
            catch(FIPAException ex)
            {
                System.out.println("el agente :"  + getLocalName()  + "No ha podido registrar el servicio : "  + ex.getMessage());
            }
        }
        
        
        
        
        
    }
    
